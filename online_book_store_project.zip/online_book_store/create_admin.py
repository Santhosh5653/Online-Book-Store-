from werkzeug.security import generate_password_hash
from database import get_db_connection

username = "admin"
password = "admin123"

conn = get_db_connection()
if not conn:
    print("Database connection failed. Check database.py")
    raise SystemExit

cursor = conn.cursor()
cursor.execute("SELECT id FROM admins WHERE username=%s", (username,))
existing = cursor.fetchone()

hashed = generate_password_hash(password)

if existing:
    cursor.execute("UPDATE admins SET password=%s WHERE username=%s", (hashed, username))
else:
    cursor.execute("INSERT INTO admins(username,password) VALUES(%s,%s)", (username, hashed))

conn.commit()
cursor.close()
conn.close()

print("Admin created successfully.")
print("Username: admin")
print("Password: admin123")
print("Change this password for real deployment.")
