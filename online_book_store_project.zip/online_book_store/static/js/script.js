document.addEventListener("DOMContentLoaded", function () {
  const registerForm = document.getElementById("registerForm");
  if (registerForm) {
    registerForm.addEventListener("submit", function (e) {
      const p1 = document.getElementById("password").value;
      const p2 = document.getElementById("confirmPassword").value;
      const msg = document.getElementById("passwordMessage");

      if (p1 !== p2) {
        e.preventDefault();
        msg.textContent = "Passwords do not match.";
        msg.className = "small mt-2 text-danger";
      }
    });
  }

  setTimeout(() => {
    document.querySelectorAll(".alert").forEach((el) => {
      try {
        bootstrap.Alert.getOrCreateInstance(el).close();
      } catch (e) {}
    });
  }, 5000);
});
