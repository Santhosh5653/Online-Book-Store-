CREATE DATABASE IF NOT EXISTS online_book_store;
USE online_book_store;

SET FOREIGN_KEY_CHECKS=0;
DROP TABLE IF EXISTS order_items;
DROP TABLE IF EXISTS orders;
DROP TABLE IF EXISTS cart;
DROP TABLE IF EXISTS books;
DROP TABLE IF EXISTS categories;
DROP TABLE IF EXISTS admins;
DROP TABLE IF EXISTS users;
SET FOREIGN_KEY_CHECKS=1;

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    phone VARCHAR(20) NOT NULL,
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE admins (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL
);

CREATE TABLE categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE
);

CREATE TABLE books (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    author VARCHAR(150) NOT NULL,
    category_id INT,
    description TEXT,
    price DECIMAL(10,2) NOT NULL,
    stock INT NOT NULL DEFAULT 0,
    image VARCHAR(500),
    rating DECIMAL(2,1) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES categories(id)
        ON UPDATE CASCADE
        ON DELETE SET NULL
);

CREATE TABLE cart (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    book_id INT NOT NULL,
    quantity INT NOT NULL DEFAULT 1,
    UNIQUE KEY unique_cart_item (user_id, book_id),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (book_id) REFERENCES books(id) ON DELETE CASCADE
);

CREATE TABLE orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    total_amount DECIMAL(10,2) NOT NULL,
    address TEXT NOT NULL,
    city VARCHAR(100) NOT NULL,
    state VARCHAR(100) NOT NULL,
    pincode VARCHAR(10) NOT NULL,
    payment_method VARCHAR(50) NOT NULL,
    status VARCHAR(50) NOT NULL DEFAULT 'Placed',
    order_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE TABLE order_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    book_id INT NOT NULL,
    quantity INT NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    FOREIGN KEY (book_id) REFERENCES books(id)
);

INSERT INTO categories(name) VALUES
('Fiction'),
('Science'),
('Technology'),
('Programming'),
('AI & Machine Learning'),
('Business'),
('Self-Help'),
('History'),
('Comics'),
('Academic');

INSERT INTO books(title, author, category_id, description, price, stock, image, rating) VALUES
('The Silent Library','Mira Sen',1,'A thoughtful fiction story about memories, books and second chances.',399.00,12,'https://images.unsplash.com/photo-1544947950-fa07a98d237f?auto=format&fit=crop&w=600&q=80',4.5),
('Cosmos and Beyond','Arjun Rao',2,'A beginner-friendly exploration of stars, galaxies and the modern universe.',549.00,10,'https://images.unsplash.com/photo-1532012197267-da84d127e765?auto=format&fit=crop&w=600&q=80',4.6),
('Future Tech Essentials','Neha Kapoor',3,'An overview of cloud, IoT, cybersecurity, blockchain and emerging technologies.',499.00,15,'https://images.unsplash.com/photo-1516979187457-637abb4f9353?auto=format&fit=crop&w=600&q=80',4.3),
('Python for Beginners','Ravi Sharma',4,'Learn Python step by step with examples, exercises and mini projects.',449.00,20,'https://images.unsplash.com/photo-1512820790803-83ca734da794?auto=format&fit=crop&w=600&q=80',4.8),
('Flask Web Development Basics','Kiran Mehta',4,'Build practical web applications using Flask, HTML, CSS and MySQL.',599.00,14,'https://images.unsplash.com/photo-1495446815901-a7297e633e8d?auto=format&fit=crop&w=600&q=80',4.7),
('AI Made Simple','Priya Nair',5,'A clear introduction to artificial intelligence for students and beginners.',649.00,18,'https://images.unsplash.com/photo-1507842217343-583bb7270b66?auto=format&fit=crop&w=600&q=80',4.9),
('Machine Learning Projects','Vikram Joshi',5,'Hands-on machine learning project ideas with practical guidance.',749.00,11,'https://images.unsplash.com/photo-1526243741027-444d633d7365?auto=format&fit=crop&w=600&q=80',4.8),
('Startup Mindset','Ananya Verma',6,'Understand business ideas, customers, product thinking and early-stage startups.',529.00,9,'https://images.unsplash.com/photo-1497633762265-9d179a990aa6?auto=format&fit=crop&w=600&q=80',4.4),
('Money and Business Basics','Rahul Iyer',6,'Simple concepts of finance, business planning, pricing and decision making.',479.00,16,'https://images.unsplash.com/photo-1491841550275-ad7854e35ca6?auto=format&fit=crop&w=600&q=80',4.2),
('Build Better Habits','Sneha Kulkarni',7,'Practical methods to build strong habits and improve daily productivity.',399.00,22,'https://images.unsplash.com/photo-1481627834876-b7833e8f5570?auto=format&fit=crop&w=600&q=80',4.6),
('Focus for Students','Aman Gupta',7,'A practical guide for students to improve focus, consistency and learning.',349.00,19,'https://images.unsplash.com/photo-1543002588-bfa74002ed7e?auto=format&fit=crop&w=600&q=80',4.5),
('India Through the Ages','S. Krishnan',8,'An accessible introduction to major periods in Indian history.',599.00,13,'https://images.unsplash.com/photo-1521587760476-6c12a4b040da?auto=format&fit=crop&w=600&q=80',4.4),
('Legends in Panels','Comic Works',9,'A colorful comic collection featuring heroes, humor and adventure.',299.00,25,'https://images.unsplash.com/photo-1576872381149-7847515ce5d8?auto=format&fit=crop&w=600&q=80',4.1),
('Data Structures Made Easy','P. Ramesh',10,'Student-friendly notes and examples for arrays, stacks, queues, trees and graphs.',559.00,17,'https://images.unsplash.com/photo-1524578271613-d550eacf6090?auto=format&fit=crop&w=600&q=80',4.7),
('Computer Networks Essentials','L. Harish',10,'Exam-focused explanations of networking models, protocols, routing and security.',579.00,12,'https://images.unsplash.com/photo-1524995997946-a1c2e315a42f?auto=format&fit=crop&w=600&q=80',4.6);

-- Admin account must be created with a hashed password.
-- Run create_admin.py after installing requirements.
