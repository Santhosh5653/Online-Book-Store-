from flask import Flask, render_template, request, redirect, url_for, session, flash
from werkzeug.security import generate_password_hash, check_password_hash
from database import get_db_connection
from functools import wraps
from datetime import datetime
import os

app = Flask(__name__)
app.secret_key = "change-this-secret-key-before-deployment"

# -----------------------------
# Helpers
# -----------------------------

def query_db(query, params=(), fetchone=False, commit=False):
    conn = get_db_connection()
    if not conn:
        raise RuntimeError("Database connection failed.")
    cursor = conn.cursor(dictionary=True)
    try:
        cursor.execute(query, params)
        if commit:
            conn.commit()
            return cursor.lastrowid
        return cursor.fetchone() if fetchone else cursor.fetchall()
    finally:
        cursor.close()
        conn.close()

def customer_login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if "user_id" not in session:
            flash("Please login first.", "warning")
            return redirect(url_for("login"))
        return f(*args, **kwargs)
    return decorated_function

def admin_login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if "admin_id" not in session:
            flash("Admin login required.", "danger")
            return redirect(url_for("admin_login"))
        return f(*args, **kwargs)
    return decorated_function

def cart_count():
    if "user_id" not in session:
        return 0
    result = query_db(
        "SELECT COALESCE(SUM(quantity),0) AS count FROM cart WHERE user_id=%s",
        (session["user_id"],),
        fetchone=True,
    )
    return result["count"] if result else 0

@app.context_processor
def inject_cart_count():
    try:
        return {"cart_count": cart_count()}
    except Exception:
        return {"cart_count": 0}

# -----------------------------
# Public/User Routes
# -----------------------------

@app.route("/")
def index():
    featured = query_db("""
        SELECT b.*, c.name AS category_name
        FROM books b
        LEFT JOIN categories c ON b.category_id=c.id
        ORDER BY b.rating DESC, b.created_at DESC
        LIMIT 8
    """)
    categories = query_db("SELECT * FROM categories ORDER BY name LIMIT 10")
    return render_template("index.html", featured=featured, categories=categories)

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        email = request.form.get("email", "").strip().lower()
        phone = request.form.get("phone", "").strip()
        password = request.form.get("password", "")
        confirm_password = request.form.get("confirm_password", "")

        if not all([name, email, phone, password, confirm_password]):
            flash("All fields are required.", "danger")
            return render_template("register.html")

        if password != confirm_password:
            flash("Passwords do not match.", "danger")
            return render_template("register.html")

        if len(password) < 6:
            flash("Password must be at least 6 characters.", "danger")
            return render_template("register.html")

        existing = query_db("SELECT id FROM users WHERE email=%s", (email,), fetchone=True)
        if existing:
            flash("Email already registered.", "warning")
            return render_template("register.html")

        hashed = generate_password_hash(password)
        query_db(
            "INSERT INTO users(name,email,phone,password) VALUES(%s,%s,%s,%s)",
            (name, email, phone, hashed),
            commit=True
        )
        flash("Registration successful. Please login.", "success")
        return redirect(url_for("login"))

    return render_template("register.html")

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")

        user = query_db("SELECT * FROM users WHERE email=%s", (email,), fetchone=True)
        if user and check_password_hash(user["password"], password):
            session.clear()
            session["user_id"] = user["id"]
            session["user_name"] = user["name"]
            flash("Login successful.", "success")
            return redirect(url_for("index"))

        flash("Invalid email or password.", "danger")
    return render_template("login.html")

@app.route("/logout")
def logout():
    session.clear()
    flash("Logged out successfully.", "info")
    return redirect(url_for("index"))

@app.route("/books")
def books():
    category_id = request.args.get("category", type=int)
    if category_id:
        books_list = query_db("""
            SELECT b.*, c.name AS category_name
            FROM books b
            LEFT JOIN categories c ON b.category_id=c.id
            WHERE b.category_id=%s
            ORDER BY b.title
        """, (category_id,))
    else:
        books_list = query_db("""
            SELECT b.*, c.name AS category_name
            FROM books b
            LEFT JOIN categories c ON b.category_id=c.id
            ORDER BY b.title
        """)
    categories = query_db("SELECT * FROM categories ORDER BY name")
    return render_template("books.html", books=books_list, categories=categories)

@app.route("/book/<int:id>")
def book_details(id):
    book = query_db("""
        SELECT b.*, c.name AS category_name
        FROM books b
        LEFT JOIN categories c ON b.category_id=c.id
        WHERE b.id=%s
    """, (id,), fetchone=True)

    if not book:
        flash("Book not found.", "danger")
        return redirect(url_for("books"))
    return render_template("book_details.html", book=book)

@app.route("/search")
def search():
    q = request.args.get("q", "").strip()
    like = f"%{q}%"
    books_list = query_db("""
        SELECT b.*, c.name AS category_name
        FROM books b
        LEFT JOIN categories c ON b.category_id=c.id
        WHERE b.title LIKE %s OR b.author LIKE %s OR c.name LIKE %s
        ORDER BY b.title
    """, (like, like, like))
    categories = query_db("SELECT * FROM categories ORDER BY name")
    return render_template("books.html", books=books_list, categories=categories, search_query=q)

@app.route("/category/<int:id>")
def category(id):
    return redirect(url_for("books", category=id))

@app.route("/add_to_cart/<int:id>", methods=["POST", "GET"])
@customer_login_required
def add_to_cart(id):
    book = query_db("SELECT * FROM books WHERE id=%s", (id,), fetchone=True)
    if not book:
        flash("Book not found.", "danger")
        return redirect(url_for("books"))

    if book["stock"] <= 0:
        flash("Book is out of stock.", "warning")
        return redirect(request.referrer or url_for("books"))

    quantity = request.form.get("quantity", 1, type=int)
    quantity = max(1, quantity)

    existing = query_db(
        "SELECT * FROM cart WHERE user_id=%s AND book_id=%s",
        (session["user_id"], id),
        fetchone=True
    )

    if existing:
        new_qty = min(existing["quantity"] + quantity, book["stock"])
        query_db(
            "UPDATE cart SET quantity=%s WHERE id=%s",
            (new_qty, existing["id"]),
            commit=True
        )
    else:
        query_db(
            "INSERT INTO cart(user_id,book_id,quantity) VALUES(%s,%s,%s)",
            (session["user_id"], id, min(quantity, book["stock"])),
            commit=True
        )

    flash("Book added to cart.", "success")
    if request.form.get("buy_now") == "1":
        return redirect(url_for("checkout"))
    return redirect(request.referrer or url_for("cart"))

@app.route("/cart")
@customer_login_required
def cart():
    items = query_db("""
        SELECT cart.id AS cart_id, cart.quantity, b.*, c.name AS category_name,
               (cart.quantity * b.price) AS line_total
        FROM cart
        JOIN books b ON cart.book_id=b.id
        LEFT JOIN categories c ON b.category_id=c.id
        WHERE cart.user_id=%s
    """, (session["user_id"],))
    total = sum(float(item["line_total"]) for item in items)
    return render_template("cart.html", items=items, total=total)

@app.route("/remove_from_cart/<int:id>")
@customer_login_required
def remove_from_cart(id):
    query_db(
        "DELETE FROM cart WHERE id=%s AND user_id=%s",
        (id, session["user_id"]),
        commit=True
    )
    flash("Item removed from cart.", "info")
    return redirect(url_for("cart"))

@app.route("/update_cart", methods=["POST"])
@customer_login_required
def update_cart():
    cart_id = request.form.get("cart_id", type=int)
    quantity = request.form.get("quantity", type=int)

    item = query_db("""
        SELECT cart.*, books.stock
        FROM cart JOIN books ON cart.book_id=books.id
        WHERE cart.id=%s AND cart.user_id=%s
    """, (cart_id, session["user_id"]), fetchone=True)

    if not item:
        flash("Cart item not found.", "danger")
        return redirect(url_for("cart"))

    if quantity is None or quantity < 1:
        flash("Quantity must be at least 1.", "warning")
    elif quantity > item["stock"]:
        flash("Requested quantity exceeds available stock.", "warning")
    else:
        query_db("UPDATE cart SET quantity=%s WHERE id=%s", (quantity, cart_id), commit=True)
        flash("Cart updated.", "success")
    return redirect(url_for("cart"))

@app.route("/checkout")
@customer_login_required
def checkout():
    items = query_db("""
        SELECT cart.quantity, b.*
        FROM cart
        JOIN books b ON cart.book_id=b.id
        WHERE cart.user_id=%s
    """, (session["user_id"],))
    if not items:
        flash("Your cart is empty.", "warning")
        return redirect(url_for("books"))

    user = query_db("SELECT * FROM users WHERE id=%s", (session["user_id"],), fetchone=True)
    total = sum(float(item["price"]) * item["quantity"] for item in items)
    return render_template("checkout.html", items=items, user=user, total=total)

@app.route("/place_order", methods=["POST"])
@customer_login_required
def place_order():
    name = request.form.get("name", "").strip()
    email = request.form.get("email", "").strip()
    phone = request.form.get("phone", "").strip()
    address = request.form.get("address", "").strip()
    city = request.form.get("city", "").strip()
    state = request.form.get("state", "").strip()
    pincode = request.form.get("pincode", "").strip()
    payment_method = request.form.get("payment_method", "").strip()

    if not all([name, email, phone, address, city, state, pincode, payment_method]):
        flash("All checkout fields are required.", "danger")
        return redirect(url_for("checkout"))

    cart_items = query_db("""
        SELECT cart.quantity, b.*
        FROM cart
        JOIN books b ON cart.book_id=b.id
        WHERE cart.user_id=%s
    """, (session["user_id"],))

    if not cart_items:
        flash("Your cart is empty.", "warning")
        return redirect(url_for("books"))

    for item in cart_items:
        if item["quantity"] > item["stock"]:
            flash(f"Not enough stock for {item['title']}.", "danger")
            return redirect(url_for("cart"))

    total = sum(float(item["price"]) * item["quantity"] for item in cart_items)

    conn = get_db_connection()
    if not conn:
        flash("Database connection failed.", "danger")
        return redirect(url_for("checkout"))

    cursor = conn.cursor(dictionary=True)
    try:
        conn.start_transaction()

        cursor.execute("""
            INSERT INTO orders(user_id,total_amount,address,city,state,pincode,payment_method,status,order_date)
            VALUES(%s,%s,%s,%s,%s,%s,%s,%s,NOW())
        """, (
            session["user_id"], total, address, city, state,
            pincode, payment_method, "Placed"
        ))
        order_id = cursor.lastrowid

        for item in cart_items:
            cursor.execute("""
                INSERT INTO order_items(order_id,book_id,quantity,price)
                VALUES(%s,%s,%s,%s)
            """, (order_id, item["id"], item["quantity"], item["price"]))

            cursor.execute(
                "UPDATE books SET stock=stock-%s WHERE id=%s",
                (item["quantity"], item["id"])
            )

        cursor.execute("DELETE FROM cart WHERE user_id=%s", (session["user_id"],))
        conn.commit()

        session["last_order_customer"] = {
            "name": name, "email": email, "phone": phone
        }
        return redirect(url_for("order_success", order_id=order_id))

    except Exception as e:
        conn.rollback()
        print("Order error:", e)
        flash("Could not place order. Please try again.", "danger")
        return redirect(url_for("checkout"))
    finally:
        cursor.close()
        conn.close()

@app.route("/order_success/<int:order_id>")
@customer_login_required
def order_success(order_id):
    order = query_db("""
        SELECT * FROM orders WHERE id=%s AND user_id=%s
    """, (order_id, session["user_id"]), fetchone=True)

    if not order:
        flash("Order not found.", "danger")
        return redirect(url_for("my_orders"))

    items = query_db("""
        SELECT oi.*, b.title, b.author, b.image
        FROM order_items oi
        JOIN books b ON oi.book_id=b.id
        WHERE oi.order_id=%s
    """, (order_id,))

    customer = session.get("last_order_customer", {})
    return render_template("order_success.html", order=order, items=items, customer=customer)

@app.route("/my_orders")
@customer_login_required
def my_orders():
    orders = query_db("""
        SELECT * FROM orders
        WHERE user_id=%s
        ORDER BY order_date DESC
    """, (session["user_id"],))

    for order in orders:
        order["items"] = query_db("""
            SELECT oi.*, b.title
            FROM order_items oi
            JOIN books b ON oi.book_id=b.id
            WHERE oi.order_id=%s
        """, (order["id"],))

    return render_template("my_orders.html", orders=orders)

@app.route("/about")
def about():
    return render_template("about.html")

@app.route("/contact", methods=["GET", "POST"])
def contact():
    if request.method == "POST":
        flash("Thanks! Your message has been received (demo only).", "success")
        return redirect(url_for("contact"))
    return render_template("contact.html")

# -----------------------------
# Admin Routes
# -----------------------------

@app.route("/admin/login", methods=["GET", "POST"])
def admin_login():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")

        admin = query_db("SELECT * FROM admins WHERE username=%s", (username,), fetchone=True)
        if admin and check_password_hash(admin["password"], password):
            session.clear()
            session["admin_id"] = admin["id"]
            session["admin_username"] = admin["username"]
            flash("Admin login successful.", "success")
            return redirect(url_for("admin_dashboard"))

        flash("Invalid admin credentials.", "danger")
    return render_template("admin/login.html")

@app.route("/admin/logout")
def admin_logout():
    session.clear()
    flash("Admin logged out.", "info")
    return redirect(url_for("admin_login"))

@app.route("/admin/dashboard")
@admin_login_required
def admin_dashboard():
    total_books = query_db("SELECT COUNT(*) AS c FROM books", fetchone=True)["c"]
    total_users = query_db("SELECT COUNT(*) AS c FROM users", fetchone=True)["c"]
    total_orders = query_db("SELECT COUNT(*) AS c FROM orders", fetchone=True)["c"]
    total_sales = query_db(
        "SELECT COALESCE(SUM(total_amount),0) AS s FROM orders WHERE status!='Cancelled'",
        fetchone=True
    )["s"]

    recent_orders = query_db("""
        SELECT o.*, u.name
        FROM orders o
        JOIN users u ON o.user_id=u.id
        ORDER BY o.order_date DESC
        LIMIT 8
    """)

    return render_template(
        "admin/dashboard.html",
        total_books=total_books,
        total_users=total_users,
        total_orders=total_orders,
        total_sales=total_sales,
        recent_orders=recent_orders
    )

@app.route("/admin/books")
@admin_login_required
def admin_books():
    books_list = query_db("""
        SELECT b.*, c.name AS category_name
        FROM books b
        LEFT JOIN categories c ON b.category_id=c.id
        ORDER BY b.id DESC
    """)
    categories = query_db("SELECT * FROM categories ORDER BY name")
    return render_template("admin/books.html", books=books_list, categories=categories)

@app.route("/admin/add_book", methods=["GET", "POST"])
@admin_login_required
def admin_add_book():
    categories = query_db("SELECT * FROM categories ORDER BY name")
    if request.method == "POST":
        title = request.form.get("title", "").strip()
        author = request.form.get("author", "").strip()
        category_id = request.form.get("category_id", type=int)
        description = request.form.get("description", "").strip()
        price = request.form.get("price", type=float)
        stock = request.form.get("stock", type=int)
        image = request.form.get("image", "").strip() or "https://via.placeholder.com/300x420?text=Book"
        rating = request.form.get("rating", type=float)

        if not title or not author or not category_id or price is None or stock is None:
            flash("Please fill all required fields.", "danger")
        else:
            query_db("""
                INSERT INTO books(title,author,category_id,description,price,stock,image,rating)
                VALUES(%s,%s,%s,%s,%s,%s,%s,%s)
            """, (title, author, category_id, description, price, stock, image, rating or 0), commit=True)
            flash("Book added successfully.", "success")
            return redirect(url_for("admin_books"))

    return render_template("admin/add_book.html", categories=categories)

@app.route("/admin/edit_book/<int:id>", methods=["GET", "POST"])
@admin_login_required
def admin_edit_book(id):
    book = query_db("SELECT * FROM books WHERE id=%s", (id,), fetchone=True)
    if not book:
        flash("Book not found.", "danger")
        return redirect(url_for("admin_books"))

    categories = query_db("SELECT * FROM categories ORDER BY name")

    if request.method == "POST":
        title = request.form.get("title", "").strip()
        author = request.form.get("author", "").strip()
        category_id = request.form.get("category_id", type=int)
        description = request.form.get("description", "").strip()
        price = request.form.get("price", type=float)
        stock = request.form.get("stock", type=int)
        image = request.form.get("image", "").strip()
        rating = request.form.get("rating", type=float)

        query_db("""
            UPDATE books
            SET title=%s,author=%s,category_id=%s,description=%s,
                price=%s,stock=%s,image=%s,rating=%s
            WHERE id=%s
        """, (title, author, category_id, description, price, stock, image, rating, id), commit=True)

        flash("Book updated successfully.", "success")
        return redirect(url_for("admin_books"))

    return render_template("admin/edit_book.html", book=book, categories=categories)

@app.route("/admin/delete_book/<int:id>", methods=["POST"])
@admin_login_required
def admin_delete_book(id):
    try:
        query_db("DELETE FROM books WHERE id=%s", (id,), commit=True)
        flash("Book deleted.", "success")
    except Exception:
        flash("Book cannot be deleted because it may be used in an existing order.", "danger")
    return redirect(url_for("admin_books"))


@app.route("/admin/categories", methods=["GET", "POST"])
@admin_login_required
def admin_categories():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        if not name:
            flash("Category name is required.", "danger")
        else:
            try:
                query_db("INSERT INTO categories(name) VALUES(%s)", (name,), commit=True)
                flash("Category added successfully.", "success")
            except Exception:
                flash("Category already exists or could not be added.", "warning")
        return redirect(url_for("admin_categories"))

    categories = query_db("""
        SELECT c.*, COUNT(b.id) AS book_count
        FROM categories c
        LEFT JOIN books b ON b.category_id=c.id
        GROUP BY c.id, c.name
        ORDER BY c.name
    """)
    return render_template("admin/categories.html", categories=categories)

@app.route("/admin/edit_category/<int:id>", methods=["POST"])
@admin_login_required
def admin_edit_category(id):
    name = request.form.get("name", "").strip()
    if not name:
        flash("Category name is required.", "danger")
    else:
        try:
            query_db("UPDATE categories SET name=%s WHERE id=%s", (name, id), commit=True)
            flash("Category updated.", "success")
        except Exception:
            flash("Could not update category.", "danger")
    return redirect(url_for("admin_categories"))

@app.route("/admin/delete_category/<int:id>", methods=["POST"])
@admin_login_required
def admin_delete_category(id):
    row = query_db("SELECT COUNT(*) AS c FROM books WHERE category_id=%s", (id,), fetchone=True)
    if row and row["c"] > 0:
        flash("Move/delete books in this category before deleting it.", "warning")
    else:
        query_db("DELETE FROM categories WHERE id=%s", (id,), commit=True)
        flash("Category deleted.", "success")
    return redirect(url_for("admin_categories"))


@app.route("/admin/users")
@admin_login_required
def admin_users():
    users = query_db("SELECT id,name,email,phone,created_at FROM users ORDER BY created_at DESC")
    return render_template("admin/users.html", users=users)

@app.route("/admin/orders")
@admin_login_required
def admin_orders():
    orders = query_db("""
        SELECT o.*, u.name, u.email, u.phone
        FROM orders o
        JOIN users u ON o.user_id=u.id
        ORDER BY o.order_date DESC
    """)
    return render_template("admin/orders.html", orders=orders)

@app.route("/admin/update_order/<int:id>", methods=["POST"])
@admin_login_required
def admin_update_order(id):
    status = request.form.get("status", "")
    allowed = ["Placed", "Processing", "Shipped", "Delivered", "Cancelled"]
    if status not in allowed:
        flash("Invalid status.", "danger")
        return redirect(url_for("admin_orders"))

    query_db("UPDATE orders SET status=%s WHERE id=%s", (status, id), commit=True)
    flash("Order status updated.", "success")
    return redirect(url_for("admin_orders"))

# -----------------------------
# Error handlers
# -----------------------------

@app.errorhandler(404)
def not_found(error):
    return render_template("404.html"), 404

@app.errorhandler(500)
def server_error(error):
    return render_template("500.html"), 500

if __name__ == "__main__":
    app.run(debug=True)
