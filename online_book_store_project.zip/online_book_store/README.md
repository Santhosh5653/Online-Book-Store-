# Online Book Store

A complete B.Tech student project built using Python Flask, MySQL, HTML5, CSS3, JavaScript, Bootstrap and Font Awesome.

## Features

### Customer
- Register and login
- Secure password hashing
- Browse books
- Search by title, author or category
- Category filtering
- View book details
- Add books to cart
- Update quantity and remove items
- Checkout
- Cash on Delivery
- Dummy/Mock online payment option
- Order confirmation
- My Orders
- Responsive design

### Admin
- Secure admin login
- Dashboard
- Total Books, Users, Orders and Sales
- Add books
- Edit books
- Delete books
- Manage categories
- View registered users
- View orders
- Update order status

## Technologies Used

- Python 3
- Flask
- MySQL
- mysql-connector-python
- Werkzeug password hashing
- HTML5
- CSS3
- JavaScript
- Bootstrap 5
- Font Awesome

## Project Structure

```text
online_book_store/
├── app.py
├── database.py
├── create_admin.py
├── requirements.txt
├── README.md
├── database/
│   └── online_book_store.sql
├── static/
│   ├── css/style.css
│   ├── js/script.js
│   └── images/
└── templates/
    ├── base.html
    ├── index.html
    ├── login.html
    ├── register.html
    ├── books.html
    ├── book_details.html
    ├── cart.html
    ├── checkout.html
    ├── order_success.html
    ├── my_orders.html
    ├── about.html
    ├── contact.html
    ├── 404.html
    ├── 500.html
    └── admin/
        ├── base_admin.html
        ├── login.html
        ├── dashboard.html
        ├── books.html
        ├── categories.html
        ├── add_book.html
        ├── edit_book.html
        ├── users.html
        └── orders.html
```

## Installation

### 1. Install software

Install:
- Python 3.11+
- MySQL Server 8+
- MySQL Workbench (recommended)
- VS Code

### 2. Create virtual environment

Windows:

```bash
python -m venv venv
venv\Scripts\activate
```

### 3. Install Python packages

```bash
pip install -r requirements.txt
```

### 4. Create MySQL database

Open MySQL Workbench.

Open:

```text
database/online_book_store.sql
```

Execute the entire SQL file.

It creates the database, tables, categories and 15 sample books.

### 5. Configure database password

Open `database.py` and change:

```python
"password": "YOUR_MYSQL_PASSWORD"
```

to your real MySQL root password.

Example:

```python
"password": "root123"
```

### 6. Create Admin Account

Run:

```bash
python create_admin.py
```

Default admin credentials:

```text
Username: admin
Password: admin123
```

Change these credentials before deploying publicly.

### 7. Run Flask

```bash
python app.py
```

Open:

```text
http://127.0.0.1:5000
```

Admin:

```text
http://127.0.0.1:5000/admin/login
```

## Testing Instructions

### Registration
1. Open Register.
2. Enter name, email, phone and matching passwords.
3. Submit.
4. Try the same email again to test duplicate-email validation.

### Login
1. Login with registered email/password.
2. Try an incorrect password to test validation.

### Books
1. Open Books.
2. Search by title, author or category.
3. Filter by category.
4. Open a book detail page.

### Cart
1. Add a book.
2. Increase/decrease quantity.
3. Remove a book.
4. Try a quantity higher than stock.

### Checkout
1. Add at least one book.
2. Open checkout.
3. Enter address details.
4. Choose Cash on Delivery or Mock Online Payment.
5. Place order.
6. Check My Orders.

### Admin
1. Login at `/admin/login`.
2. Add a new book.
3. Edit a book.
4. Delete a book not used by an order.
5. View users.
6. View orders.
7. Update order status.

## Common Errors and Solutions

### Error: `ModuleNotFoundError: No module named 'mysql'`

Run:

```bash
pip install mysql-connector-python
```

### Error: `Access denied for user 'root'@'localhost'`

Your MySQL password is wrong. Update `database.py`.

### Error: `Can't connect to MySQL server on 'localhost:3306'`

Start MySQL Server from Windows Services or MySQL Installer.

### Error: `Unknown database 'online_book_store'`

Run `database/online_book_store.sql` in MySQL Workbench.

### Error: Admin login does not work

Run:

```bash
python create_admin.py
```

### Error: Port 5000 already in use

Change:

```python
app.run(debug=True)
```

to:

```python
app.run(debug=True, port=5001)
```

### Error: Images not loading

The sample project uses public image URLs. Internet access is required for those images. You can replace them with local files inside `static/images/`.

## Security Notes

This project includes:
- Password hashing with Werkzeug
- Parameterized MySQL queries
- Flask sessions
- Login protection
- Admin route protection
- Basic form validation
- No real payment integration

Before real deployment:
- Use environment variables for secret keys and DB passwords
- Use CSRF protection (Flask-WTF)
- Use HTTPS
- Add stronger validation
- Add role/permission management
- Use production WSGI server

## Screenshots Section

Add screenshots here after running the application:

1. Home Page
2. Books Page
3. Book Details
4. Cart
5. Checkout
6. Order Success
7. Admin Dashboard
8. Admin Books
9. Admin Orders

## Future Enhancements

- Wishlist
- Book reviews
- User profile
- Coupon system
- Email notifications
- Pagination
- Recommendation system using AI/ML
- REST API
- Real payment gateway
- Cloud deployment
- Image upload instead of image URLs
